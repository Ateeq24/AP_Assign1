#include "StringBuffer.h"
#include "String.h"
#include <memory>
#include <iostream>

using namespace std;
//default constructor

String::String() {
	this->_str = new StringBuffer();
	this->_ownership = true;
}
//destructor

String::~String() {

	if (this->_ownership==true)
		delete this->_str;
	else
		cout << endl << "----Deleting the pointer Failed! Ownership Error!----" << endl;
		//this->_str = NULL;

}

//copy a const String into this string

String::String(const String& newString) {
//	this->_str = newString._str;
    this->_str=newString._str;
	this->_ownership = false;
}

//copy a char* into your string

String::String(char* newString, int length) {
	this->_str = new StringBuffer(newString, length);
	this->_ownership = true;
	//increment the refcount by 1

}

void String::append(char c) {
	if (this->_ownership == true)
	{
		//    char* tempbuf = new char[this->_str->length()+1];
		//    this->_str->revSmartCopy(tempbuf);
		//more than 1 reference to this string
		auto_ptr<StringBuffer> newdata(new StringBuffer);
	newdata.get()->reserve(this->_str->length() + 1);
	newdata.get()->smartCopy(this->_str);


	//cout<<"length at newdata"<<newdata.get()->length()<<endl;
	//now split the object instances
	this->_str = newdata.release();

	//copy the new character at the end of this string
	this->_str->append(c);
}
	else
		cout << endl << "----Appending Failed! Ownership Error!----" << endl;

}

//get length of the string

int String::length() const {
	return this->_str->length();
}

//get character at index if it is less than length

char String::charAt(int index) const {
	if (index < this->_str->length()) {
		return this->_str->charAt(index);
	}
	else {
		//throw new IndexOutOfBoundException();

	}
}