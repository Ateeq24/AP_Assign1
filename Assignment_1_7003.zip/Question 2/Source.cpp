/*
* File:   main.cpp
*
* Created on February 16, 2016, 9:51 PM
*/

#include <cstdlib>
#include <iostream>
#include<cstring>
#include "StringBuffer.h"
#include "String.h"
using namespace std;

/*
*
*/
int main(int argc, char** argv) {
	//create a smart string
	//    String ss;
	//create a smart string with const char*
	char* hello = "hello";



	String ss2(hello, 5);
	std::cout << "ss2 length = " << ss2.length() << std::endl;
	cout << hello << endl;
	//multiple references
	String ss(ss2);
	cout << hello << endl;
	//output statements
	std::cout << "ss length = " << ss.length() << std::endl;
	std::cout << "new ss charAt 0 = " << ss.charAt(0) << std::endl;
	cout <<endl<< "Appending w to ss ";

	//append a character
	ss.append('w');
	cout << endl;
	
	std::cout << "new ss length = " << ss.length() << std::endl;
	std::cout << "new ss2 length = " << ss2.length() << std::endl;
	cout <<endl<< "ss (After Appending w) = ";
	for (int i = 0; i < ss.length(); i++)
	{
		cout << ss.charAt(i);
	}
	cout << endl;
	cout << endl<<"ss2 (without Appending) = ";

	for (int i = 0; i < ss2.length();i++)
	{
		cout << ss2.charAt(i);
	}
	cout << endl<<endl << "Appending w to ss2 "<<endl;

	ss2.append('w');

	cout << "ss2 (After Appending w) = ";

	for (int i = 0; i < ss2.length(); i++)
	{
		cout << ss2.charAt(i);
	}
	cout << endl<<endl;
	system("pause");
	return 0;
}

